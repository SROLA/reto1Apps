package co.edu.icesi.code;

import android.annotation.SuppressLint;
import android.location.Location;
import android.location.LocationManager;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.HashMap;

import static android.content.Context.LOCATION_SERVICE;

public class MapController implements LocationProvider.locationListener {

    private GoogleMap mapa;
    private Marker lct;
    private double precision = 1000;
    private LocationProvider gpsP;
    private LocationProvider networkP;
    private HashMap< Double, Marker> markerHash;
    private MapFunction activity;

    public MapController(GoogleMap googleMap) {
        mapa = googleMap;
    }

    public GoogleMap getMapa() {
        return mapa;
    }

    public HashMap<Double, Marker> getMarkerHash() {
        return markerHash;
    }

    public Marker getLct() {
        return lct;
    }

    @SuppressLint("MissingPermission")
    public void init()

    {

        markerHash = new HashMap<>();

        mapa.setOnMapLongClickListener(this.activity);
        mapa.setOnMarkerClickListener(this.activity);
        LocationManager manager = (LocationManager) activity.getSystemService(LOCATION_SERVICE);


        if(manager.getLastKnownLocation(LocationManager.GPS_PROVIDER) != null)
        {
            setInitialPos(manager.getLastKnownLocation(LocationManager.GPS_PROVIDER));
        }
        else
            {
            setInitialPos(manager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER));
        }

        this.gpsP = new LocationProvider();
        gpsP.setListener(this);
        manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500,3, gpsP);

        this.networkP = new LocationProvider();
        networkP.setListener(this);
        manager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 500,3, networkP);




    }


    public void setInitialPos(Location lastKnownLocation)
    {
        LatLng aux = new LatLng(lastKnownLocation.getLatitude(), lastKnownLocation.getLongitude());
        lct = mapa.addMarker(new MarkerOptions().position(aux));
        lct.setIcon((BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE)));
    }


    @Override
    public void OnLocationReceived(Location location)
    {
        if(location.getAccuracy() <= precision)
        {
            precision = location.getAccuracy();

            LatLng pos = new LatLng(location.getLatitude(), location.getLongitude());

            lct.setPosition(pos);

            mapa.animateCamera(CameraUpdateFactory.newLatLngZoom(lct.getPosition(), 18));
            mapa.moveCamera(CameraUpdateFactory.newLatLngZoom(pos,18));

            refrescar();

            if(markerHash.containsKey(pos))
            {
                activity.getOutput().append("\n EL mas cernano a la posicion actual es: " + markerHash.get(pos).getTitle().toString());
            }
        }
    }

    public void setActivity(MapFunction activity) {
        this.activity = activity;
    }

    public static double darDistancia(double latitud1, double latitud2, double longitud1, double longitud2)
    {
        double latitud=0;

        double longitud=0;

        final int radio = 6371;

         latitud= Math.toRadians(latitud2 - latitud1);
         longitud= Math.toRadians(longitud2 - longitud1);

        double aux = Math.sin(latitud / 2) * Math.sin(latitud / 2) + Math.cos(Math.toRadians(latitud1)) * Math.cos(Math.toRadians(latitud2)) * Math.sin(longitud / 2) * Math.sin(longitud / 2);

        double aux1 = 2 * Math.atan2(Math.sqrt(aux), Math.sqrt(1 - aux));

        double distancia = radio *  aux1* 1000;

        distancia = Math.pow(distancia, 2);

        return Math.sqrt(distancia);
    }

    public Marker buscarCerca()
    {
        double distancia=0;

        distancia = Double.MAX_VALUE;

        for(double aux : markerHash.keySet())
        {
            if(aux < distancia)
                distancia = aux;
        }
        return markerHash.get(distancia);
    }

    public void refrescar()
    {
        if(buscarCerca() != null)
        {
            activity.getOutput().setText("El marcador mas cercano a la posicion actual es: " + buscarCerca().getTitle() + "\n" + darDistancia(buscarCerca().getPosition().latitude, lct.getPosition().latitude, buscarCerca().getPosition().longitude, lct.getPosition().longitude));
        }
    }

}
